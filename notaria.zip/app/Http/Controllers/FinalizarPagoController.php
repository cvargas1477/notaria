<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Finalizarpago;


class FinalizarPagoController extends Controller
{
    //
}
